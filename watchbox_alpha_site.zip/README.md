# WatchBox Alpha

Free browser game for iPhone/Safari.

## Files

- `index.html` - main game page
- `style.css` - luxury dark/gold styling
- `script.js` - game logic and save system
- `manifest.json` - Home Screen web app settings
- `icon-180.png` and `icon-512.png` - app icons

## iPhone upload path

1. Save this ZIP to Files.
2. Open the GitHub app.
3. Create a new repository called `watchbox-alpha`.
4. Upload these files into the repository root.
5. Connect the repository to Cloudflare Pages.
6. Set build command to blank and output directory to `/`.

Then open the Cloudflare Pages URL in Safari and use Share → Add to Home Screen.
